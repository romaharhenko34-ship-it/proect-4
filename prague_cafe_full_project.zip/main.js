import { initValidation } from './src/js/validation.js';

document.addEventListener('DOMContentLoaded', () => {
    // 4. Event Handling (Popup)
    const popup = document.querySelector('#bookingPopup');
    const openBtn = document.querySelector('#openBooking');
    const closeBtn = document.querySelector('.close-btn');

    if (openBtn) {
        openBtn.onclick = () => popup.classList.add('active');
        closeBtn.onclick = () => popup.classList.remove('active');
    }

    // 7. Async/Await (Weather API)
    async function getWeather() {
        const el = document.querySelector('#weather');
        try {
            const res = await fetch('https://api.open-meteo.com/v1/forecast?latitude=50.08&longitude=14.42&current_weather=true');
            const data = await res.json();
            // 3. DOM Manipulation
            el.innerHTML = `<i class="fas fa-temperature-low"></i> Прага: ${Math.round(data.current_weather.temperature)}°C`;
        } catch (e) {
            el.innerText = 'Прага';
        }
    }

    getWeather();
    initValidation();
});