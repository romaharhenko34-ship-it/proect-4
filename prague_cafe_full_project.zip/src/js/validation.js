export function initValidation() {
    const form = document.querySelector('#resForm');
    if (!form) return;

    // 6. Local Storage (Загрузка данных)
    const savedName = localStorage.getItem('guest_name');
    if (savedName) document.querySelector('#userName').value = savedName;

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.querySelector('#userName').value;
        const email = document.querySelector('#userEmail').value;

        // 5. Form Validation
        if (name.length < 2) return alert('Имя слишком короткое');
        if (!email.includes('@')) return alert('Введите корректный Email');

        // 6. Local Storage (Сохранение)
        localStorage.setItem('guest_name', name);
        
        alert(`Спасибо, ${name}! Заявка отправлена.`);
        document.querySelector('#bookingPopup').classList.remove('active');
        form.reset();
    });
}